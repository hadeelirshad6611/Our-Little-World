OUR LITTLE WORLD — MVP PROTOTYPE

This is a working browser/PWA prototype of the couples app concept.
It includes:
- Couple home
- Days-together counter
- Daily streak challenge
- Memories
- Bucket list
- Profile/together-since date
- Local storage so demo data persists in the browser

IMPORTANT:
This is a prototype, not yet a production Android app. It does not yet have real accounts, partner invitations, cloud sync, payments, push notifications, photo uploads, or Google Play packaging.

NEXT BUILD:
1. Design final UI
2. Add Firebase authentication + database
3. Connect two partners to one private couple space
4. Add secure photo/video storage
5. Add real countdowns and notifications
6. Add subscriptions
7. Build signed Android release (AAB)
8. Publish through your Google Play developer account


DESIGN NOTE: The prototype intentionally uses generic labels and contains no personal names.
